from django.shortcuts import render

# Create your views here.
from .models import *

def  login(request):
    pass

def register(request):
    pass

def user(request, login):
    context = dict()
    user = Account.objects.get(login = login)
    context['user'] = user
    return render(request, '/Users/dalenamir/Desktop/projects/stocks/stocks/templates/accounts/user.html', context)

def all(request):
    context = dict()
    users = Account.objects.all()
    context['users'] = users
    return render(request, '/Users/dalenamir/Desktop/projects/stocks/stocks/templates/accounts/all_users.html', context)
