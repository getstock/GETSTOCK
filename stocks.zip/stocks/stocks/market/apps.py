from django.apps import AppConfig


class MarketConfig(AppConfig):
    name = 'market'
